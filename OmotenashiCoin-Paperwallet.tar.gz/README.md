# OmotenashiCoin-Paperwallet
OmotenashiCoin Paper Wallet Generator.
